-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: b1dccfhhk6a41y9qoebc-mysql.services.clever-cloud.com:3306
-- Generation Time: Nov 10, 2022 at 05:36 PM
-- Server version: 8.0.15-5
-- PHP Version: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `b1dccfhhk6a41y9qoebc`
--

-- --------------------------------------------------------

--
-- Table structure for table `mascotas`
--

CREATE TABLE `mascotas` (
  `id` int(4) NOT NULL,
  `nombre` varchar(20) NOT NULL,
  `propietario` int(10) NOT NULL,
  `especie` varchar(20) NOT NULL,
  `sexo` char(1) NOT NULL,
  `nacimiento` varchar(10) NOT NULL,
  `fallecimiento` varchar(10) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT '00-00-0000'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `mascotas`
--

INSERT INTO `mascotas` (`id`, `nombre`, `propietario`, `especie`, `sexo`, `nacimiento`, `fallecimiento`) VALUES
(111, 'Fluffy', 1, 'Gato', 'f', '1999-02-04', '0000-00-00'),
(222, 'Mau', 2, 'Gato', 'm', '1998-03-17', '0000-00-00'),
(333, 'Buffy', 1, 'Perro', 'f', '1999-05-13', '0000-00-00'),
(444, 'FanFan', 3, 'Perro', 'm', '2000-08-27', '0000-00-00'),
(555, 'Kaiser', 4, 'Perro', 'm', '1998-08-31', '1997-07-29'),
(666, 'Chispa', 5, 'Ave', 'f', '1998-09-11', '0000-00-00'),
(777, 'Bicho', 6, 'Ave', '', '2000-02-09', '0000-00-00'),
(888, 'Skim', 1, 'Serpiente', 'm', '2001-04-29', '0000-00-00');

-- --------------------------------------------------------

--
-- Table structure for table `propietarios`
--

CREATE TABLE `propietarios` (
  `id_propietario` int(10) NOT NULL,
  `nombre` varchar(30) NOT NULL,
  `telefono` varchar(15) NOT NULL,
  `correo` varchar(40) NOT NULL DEFAULT '@'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `propietarios`
--

INSERT INTO `propietarios` (`id_propietario`, `nombre`, `telefono`, `correo`) VALUES
(1, 'ARNOLDO MARTINEZ', '2789456000', 'arnolodo@gmail.com'),
(2, 'JUAN PEREZ', '299803122', '@'),
(3, 'BENITO SUAREZ', '22713411', '@'),
(4, 'DIANA MARTINEZ', '5848974', '@'),
(5, 'OMAR ARANGO', '2789654', '@'),
(6, 'TOMAS CIPRIANO', '2945656', '@');

-- --------------------------------------------------------

--
-- Table structure for table `servicios`
--

CREATE TABLE `servicios` (
  `id` int(3) NOT NULL,
  `nombre` varchar(20) NOT NULL,
  `valor` float NOT NULL,
  `imagen` varchar(20) NOT NULL DEFAULT 'pata.png'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `servicios`
--

INSERT INTO `servicios` (`id`, `nombre`, `valor`, `imagen`) VALUES
(1, 'INYECTOLOGIA', 15000, 'pata.png'),
(2, 'VACUNACION', 20000, 'pata.png'),
(3, 'CIRUGIA EXTREMIDAD', 1500000, 'pata.png'),
(4, 'CITA', 5000, 'pata.png'),
(5, 'CASTRACION', 120000, 'pata.png'),
(6, 'PURGAR PARASITOS', 25000, 'pata.png'),
(7, 'PUNTO DE SUTURA', 10000, 'pata.png'),
(8, 'MATERNIDAD', 500000, 'pata.png'),
(9, 'GUARDERIA', 30000, 'guarderia.png');

-- --------------------------------------------------------

--
-- Table structure for table `servicio_mascota`
--

CREATE TABLE `servicio_mascota` (
  `consecutivo` int(3) NOT NULL,
  `id_mascota` int(3) NOT NULL,
  `id_servicio` int(3) NOT NULL,
  `cantidad` int(11) NOT NULL,
  `valor_unitario` float NOT NULL,
  `id_propietario` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `servicio_mascota`
--

INSERT INTO `servicio_mascota` (`consecutivo`, `id_mascota`, `id_servicio`, `cantidad`, `valor_unitario`, `id_propietario`) VALUES
(1, 111, 1, 2, 15000, 1),
(2, 111, 8, 2, 500000, 1),
(3, 222, 1, 2, 15000, 2),
(4, 333, 2, 2, 20000, 1),
(5, 444, 1, 2, 15000, 3),
(6, 555, 1, 2, 15000, 4),
(7, 666, 1, 2, 15000, 5),
(8, 777, 1, 2, 15000, 6),
(9, 888, 1, 2, 15000, 3);

-- --------------------------------------------------------

--
-- Table structure for table `tblusuarios`
--

CREATE TABLE `tblusuarios` (
  `id` smallint(5) UNSIGNED NOT NULL,
  `usuario` varchar(20) NOT NULL DEFAULT '',
  `perfil` int(11) NOT NULL DEFAULT '0',
  `clave` varchar(20) NOT NULL DEFAULT '',
  `correo` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tblusuarios`
--

INSERT INTO `tblusuarios` (`id`, `usuario`, `perfil`, `clave`, `correo`) VALUES
(1, 'mariano', 1, 'matOq4wkFsob6', 'mariano@gmail.com'),
(12, '8472131', 2, '84ATDd4ilTOAc', 'mediatecnicaapp@gmail.com'),
(13, 'Momo', 3, 'Mo3gToXx1ZWMI', 'momo@gmail.com');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `mascotas`
--
ALTER TABLE `mascotas`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `propietarios`
--
ALTER TABLE `propietarios`
  ADD PRIMARY KEY (`id_propietario`);

--
-- Indexes for table `servicios`
--
ALTER TABLE `servicios`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `servicio_mascota`
--
ALTER TABLE `servicio_mascota`
  ADD PRIMARY KEY (`consecutivo`);

--
-- Indexes for table `tblusuarios`
--
ALTER TABLE `tblusuarios`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `mascotas`
--
ALTER TABLE `mascotas`
  MODIFY `id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=889;

--
-- AUTO_INCREMENT for table `propietarios`
--
ALTER TABLE `propietarios`
  MODIFY `id_propietario` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=326;

--
-- AUTO_INCREMENT for table `servicio_mascota`
--
ALTER TABLE `servicio_mascota`
  MODIFY `consecutivo` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `tblusuarios`
--
ALTER TABLE `tblusuarios`
  MODIFY `id` smallint(5) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
