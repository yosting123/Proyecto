<?
$id=$_POST['id'];
if ($id==""){
 $consulta="select id, nombre, valor from servicios ";
 }else{
 $consulta="select id, nombre, valor from servicios where id=$id";
}
?>
<html>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
<head>
<title>Servicios</title>
</head>
<body>
<div class ="container">
<form action ="index.php" method="post" class="form-data">
<input type = "text" name="id">
<button type="submit" name="consultar">Buscar</button>
</form>
  <a href="index.php">Volver </a>
<?php
$host="bplp2hdytqyyrjrg3y5j-mysql.services.clever-cloud.com";
$user ="u9d18awqocvbii7o";
$pwd ="KkIWN6t450xt1wQIvmMk";

$db ="bplp2hdytqyyrjrg3y5j";
$conexion = mysqli_connect($host, $user, $pwd, $db) or
die("Problemas con la conexión");
$registros = mysqli_query($conexion, $consulta) or
die("Problemas en el select:" . mysqli_error($conexion));
echo "<table class='table table-striped'><tr><td>Código</td><td>Nombre</td><td>Valor</td>";
while ($reg = mysqli_fetch_array($registros)) {
 echo "<tr><td>" . $reg['id'] . "</td>";
 echo "<td>" . $reg['nombre'] . "</td>";
 echo "<td>" . $reg['valor'] . "</td>";
 echo "</tr>";
 }
echo "</table>";
mysqli_close($conexion);
?>
</body></div>
</html>
